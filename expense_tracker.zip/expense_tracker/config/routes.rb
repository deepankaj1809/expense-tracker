Rails.application.routes.draw do
  resources :sessions, only: [:new, :create]
  delete '/logout', to: 'sessions#destroy'
  resources :expenses, only: [:index, :new, :create]
  root 'sessions#new'
end

