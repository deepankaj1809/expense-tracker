Expense Tracker
Expense Tracker is a simple web application built with Ruby on Rails that allows users to track their expenses.

Features
1. Login: Users can log in using a basic login from the application.
2. Expense Tracking: Users can view a list of their expenses, filter expenses by date range, and see the total expenses within that range.
3. Add New Expense: Users can add new expenses to their list.

Getting Started
1. Start the server: rails server
2. Visit http://localhost:3000 in your browser.
3. Log in using username and password.
4. Explore the expense tracking functionality.
5. Click on the "New Expense" button to add new expenses.
6. Use the date range filter to view expenses within a specific time period.
