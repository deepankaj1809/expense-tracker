class ExpensesController < ApplicationController
  def index
    @expenses = Expense.all
    if params[:start_date].present? && params[:end_date].present?
      start_date = Date.parse(params[:start_date])
      end_date = Date.parse(params[:end_date])
      @expenses = @expenses.where(date: start_date..end_date)
      @total_expenses = @expenses.sum(:amount)
    end
  end

  def new
    @expense = Expense.new
  end

  def create
    @expense = Expense.new(expense_params)
    if @expense.save
      redirect_to expenses_path, notice: 'Expense was successfully created.'
    else
      render :new
    end
  end

  private

  def expense_params
    params.require(:expense).permit(:description, :amount, :date)
  end
end
