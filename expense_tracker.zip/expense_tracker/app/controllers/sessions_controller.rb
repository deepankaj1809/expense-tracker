class SessionsController < ApplicationController
  def new

  end

  def create
    if params[:username].present? && params[:password].present?
      session[:user_id] = 1
      redirect_to expenses_path, notice: "Logged in successfully"
    end
  end
end

